from flask_wtf import FlaskForm
from wtforms import PasswordField, SubmitField, TextAreaField
from wtforms.fields.html5 import EmailField, IntegerRangeField, IntegerField
from wtforms.validators import DataRequired


class Add_date(FlaskForm):
    balance = IntegerField("Num")
    submit = SubmitField('Пополнить баланс')
    