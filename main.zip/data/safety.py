from werkzeug.security import generate_password_hash, check_password_hash


class Security:
    def set_password(password):
        p = generate_password_hash(password)
        return p

    def check_password(hash, password):
        p = check_password_hash(hash, password)
        return p
