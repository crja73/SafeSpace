from flask_wtf import FlaskForm
from wtforms import TextAreaField
from flask_wtf import FlaskForm
from wtforms import  PasswordField, SubmitField, BooleanField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired


class SearchForm(FlaskForm):
    zapros = TextAreaField("Запрос")
    submit = SubmitField('Отправить')
